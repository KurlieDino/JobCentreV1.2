Locales['pl'] = {
  ['new_job'] = 'masz nową pracę!',
  ['access_job_center'] = 'wciśnij ~INPUT_PICKUP~ aby otworzyć ~b~urząd pracy~s~.',
  ['job_center'] = 'urząd Pracy',
}
