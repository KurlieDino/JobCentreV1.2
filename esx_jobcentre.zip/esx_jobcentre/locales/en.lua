Locales['en'] = {
  ['new_job'] = 'you have a new job!',
  ['access_job_center'] = 'press ~INPUT_PICKUP~ to access the ~b~job center~s~.',
  ['job_center'] = 'Job Centre',
}
