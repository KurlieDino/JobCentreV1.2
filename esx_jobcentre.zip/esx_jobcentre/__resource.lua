--Version: 1.0

client_script {
    'client/main.lua',
    '@es_extended/locale.lua',
	'config.lua',
	'locales/de.lua',
	'locales/br.lua',
	'locales/en.lua',
	'locales/fi.lua',
	'locales/fr.lua',
	'locales/es.lua',
	'locales/sv.lua',
	'locales/pl.lua',
	'locales/cs.lua',
    'config.lua'
}

server_script 'server/main.lua'

ui_page "html/jobui.html"

files {
    'html/jobui.html',
    'html/jobjs.js',
    'html/jobstyles.css',
    'html/img/jobone.png',
    'html/img/jobtwo.png',
    'html/img/jobthree.png',
    'html/img/jobfour.png',
    'html/img/jobfive.png',
    'html/img/jobsix.png'

}